<?php

function checkRequiredBody($keys){
    try {
        foreach($keys as $key) {
            if (empty($_POST[$key])){
                return false;
            }
        }
        return true;
    } catch (Exception $e) {
        return false;
    }
}


