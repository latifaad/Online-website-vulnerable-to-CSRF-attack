window.addEventListener("load", function() {

   let contactForm    = document.forms[0];
   let inputError     = contactForm.querySelectorAll('input, textarea');
   contactForm.addEventListener("submit", validation);

   function validation(event){
      
      let errorList = "";
      let count = 0;
      for( let i = 0; i < inputError.length - 1; i++){
         if(!inputError[i].value){
            errorList += "\t•  " + inputError[i].name + ", shoudn't be a balnk !!\n";
            count++;
         }
         
      }
      
      console.log(count);
      if(count > 0 ){
         event.preventDefault();
         alert(errorList);
      }
      
   }

   let userBox = document.querySelector('.header .header-2 .user-box');

   document.querySelector('#user-btn').onclick = () =>{
      userBox.classList.toggle('active');
      navbar.classList.remove('active');
   }

   let navbar = document.querySelector('.header .header-2 .navbar');

   document.querySelector('#menu-btn').onclick = () =>{
      navbar.classList.toggle('active');
      userBox.classList.remove('active');
   }

   window.onscroll = () =>{
      userBox.classList.remove('active');
      navbar.classList.remove('active');

      if(window.scrollY > 60){
         document.querySelector('.header .header-2').classList.add('active');
      }else{
         document.querySelector('.header .header-2').classList.remove('active');
      }
   }

});

