<?php
include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];
if(!isset($user_id)){
   header('location: login.php');
}

if(isset($_POST['send'])){
   $name =  htmlspecialchars($_POST['name']) ?? null; // convert pre-definde char into html entities + protect XSS
   $email = $_POST['email'] ?? null;
   $number = $_POST['number'] ?? null;
   $msg = htmlspecialchars($_POST['message']) ?? null; // convert pre-definde char into html entities + protect XSS
   $stmt = $conn->prepare("SELECT * FROM `message` WHERE name = ? AND email = ? AND number = ? AND message = ?") or die('query failed');
   $stmt->execute([$name, $email, $number, $msg]);
   if($stmt->rowCount() > 0){
      $message[] = 'Message sent already!';
   }elseif(!preg_match('/^[A-Za-z]+$/',$name)){ // name validation
         $message[] = 'Name must contain letters only';
   }elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){ // sanitization email by using filter
         $message[] = 'Email address incorrect';
   }elseif(!preg_match('/^[0-9]{10}+$/', $number)){ // phone number validation
         $message[] = 'Phone number incorrect';
   }else{
         $stmt = $conn->prepare("INSERT INTO `message`(user_id, name, email, number, message) VALUES(?, ?, ?, ?, ?)") or die('query failed');
         $result = $stmt->execute([$_SESSION['user_id'], $name, $email, $number, $msg]);
         if($result){
         $message = "Message sent successfully!";
         }
      }
   }

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="shortcut icon" href="images/logo1.jpg" type="image/x-icon">
   <title>contact</title>
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <!-- custom js file link  -->
   <script src="js/script.js"></script>
</head>
<body>
   
<?php include 'header.php'; ?>
<div class="heading">
   <h3>contact us</h3>
   <p> <a href="home.php">home</a> / contact </p>
</div>

<section class="contact">
   <div class="error_"></div> 
   <form name="myForm" action="" id="contactForm" method="post" >
      <h3>say something!</h3>
      <p id="error" class="error"></p> 
      <!-- validate name; max len = 32 -->
      <input type="text" id="name" name="name" placeholder="enter your name" maxlength='32' class="box">
       <!-- validate email by indicate type and pattern -->
      <input type="email" id="email" name="email" placeholder="enter your email" class="box">
      <!-- validate number; min-length = 10 -->
      <input type="number" id="number" name="number" placeholder="enter your phone number" maxlength='10'  class="box">
      <textarea name="message" id="meesage" class="box" placeholder="enter your message" id="" cols="30" rows="10" maxlength="3000" ></textarea>
      <input type="submit" value="send message" name="send" class="btn">
   </form>

</section>


<?php include 'footer.php'; ?>



</body>
</html>
