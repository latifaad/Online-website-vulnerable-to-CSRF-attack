<?php
include 'config.php';
session_start(); // create session 
if(isset($_POST['submit'])){  

   $name =  $_POST['name'] ?? null ;
   $email = trim($_POST['email']) ?? null; // removes whitespace and pre-defined char
   $pass = $_POST['password'];
   $cpass = $_POST['cpassword'];
   $user_type = $_POST['user_type']; 

 



   if(checkRequiredBody(['name', 'password', 'cpassword', 'user_type']) === false){
      $message[] = 'Don\'t leave anything empty!';
   }elseif($pass != $cpass){ // check matching
      $message[] = 'Confirm password not matched!';
   }elseif(!preg_match("/^[A-Za-z]+$/",$name)){ // username validation
      $message[] = 'Username must contain letters only';
   }elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){ // sanitization email by using filter
      $message[] = 'Please Enter Valid Email address';
   }elseif(strlen($pass) < 8 || !preg_match('@[0-9]@', $pass) || !preg_match('@[A-Z]@', $pass) || !preg_match('@[a-z]@', $pass) || !preg_match('@[^\w]@', $pass)) {
      $message[] =  'Password does not meet the standards';
      // password must be at least 8 char, contains numbers, contains Uppercase, contains lowercase, and characters 
   }else{

      $select_users = $conn->prepare("SELECT * FROM `users` WHERE email = ?") or die('query failed');// prepare stmt
      $reg_data = [$email]; 
      $select_users->execute($reg_data);
         if($select_users->rowCount() > 0){
         $message[] = 'user already exist!'; //check the email whethere is used or not
         }else{
            $pass = md5($_POST['password']); // secure the password by using hashing algorithm (md5)
            $stmt=$conn->prepare("INSERT INTO `users`(name, email, password, user_type) VALUES(?, ?, ?, ?)") or die('query failed'); //insert user info into DB
            $result = $stmt->execute([$name, $email, $pass, $user_type]);
            if($result){
            $message['success'] = 'registered successfully!'; 
            header('location: login.php');
         }
      }
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="shortcut icon" href="images/logo1.jpg" type="image/x-icon">
   <title>register</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <!-- custom js file link  -->
   <script src="js/script.js"></script> 
</head>
<body>



<?php
if(isset($message)){
   foreach($message as $key => $value){
      echo '
      <div class="message">
         <span ' . ($key === 'success' ? 'style="color: green"' : 'style="color: red"') . '>'.$value.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<div class="form-container">

   <form action="" method="post">
      <h3>register now</h3>
      <!-- validate name; max len = 32 -->
      <input type="text" name="name" placeholder="enter your name" maxlength='32' class="box">
      <!-- validate email;  by type -->
      <input type="email" name="email" placeholder="enter your email"  class="box"> 
      <!-- validate password and cpassword; min len = 8 -->
      <input type="password" name="password" placeholder="enter your password"  minlength='8' class="box">
      <input type="password" name="cpassword" placeholder="confirm your password"  minlength='8'  class="box">
      <select name="user_type" class="box">
      <!-- user type -> user by default -->
         <option value="user">user</option> 
      </select>
      <input type="submit" name="submit" value="register now" class="btn">
      <p>already have an account? <a href="login.php">login now</a></p>
   </form>

</div>
</body>
</html>

