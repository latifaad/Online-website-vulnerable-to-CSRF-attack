<?php
include 'config.php';
session_start();
$admin_id = $_SESSION['admin_id'];
if(!isset($admin_id)){
   header('location: login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="shortcut icon" href="images/logo1.jpg" type="image/x-icon">
   <title>admin panel</title>
   <!-- font awesome cdn link  source: https://cdnjs.com/libraries/font-awesome/6.0.0 -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">
</head>
<body>
   
<?php include 'admin_header.php'; ?>
<!-- admin dashboard section starts  -->
<section class="dashboard">
   <h1 class="title">dashboard</h1>
   <div class="box-container">
      <div class="box">
         <?php
            $total_pendings = 0;
            $stmt = $conn->prepare("SELECT sum(total_price) AS total_price_sum FROM `orders` WHERE payment_status = ?");
			   $orders_status = ['pending'];
			   $stmt->execute($orders_status);
			   if($stmt->rowCount() > 0){
			      $rows = $stmt->fetch();
               if($rows['total_price_sum'] == ''){
                  $rows['total_price_sum'] = 0;
               } 
               
            }
         ?>
         <h3><?php echo $rows['total_price_sum'] . ' SR'; ?></h3>
         <p>total pendings</p>
      </div>
      <div class="box">
         <?php
            $total_completed = 0;
            $stmt = $conn->prepare("SELECT sum(total_price) AS total_price_sum FROM `orders` WHERE payment_status = ? ") or die('query failed');
            $orders_status = ['completed'];
            $stmt->execute($orders_status);
			   if($stmt->rowCount() > 0){
			      $rows = $stmt->fetch();
               if($rows['total_price_sum'] == ''){
                  $rows['total_price_sum'] = 0;
               } 
               
            }
         ?>
         <h3><?php echo $rows['total_price_sum'] . ' SR'; ?></h3>
         <p>completed payments</p>
      </div>
      <div class="box">
         <?php 
			
			$get_all_orders = $conn->prepare("SELECT * FROM orders") or die('query failed');
			$get_all_orders->execute();
			if($get_all_orders->rowCount() > 0){
			$number_of_orders = $get_all_orders->rowCount();
            }else {
				$number_of_orders = 0;
			}
         ?>
         <h3><?php echo $number_of_orders; ?></h3>
         <p>order placed</p>
      </div>

      <div class="box">
         <?php 

			$get_all_products = $conn->prepare("SELECT * FROM products") or die('query failed');
			$get_all_products->execute();
			if($get_all_products->rowCount() > 0){
			$number_of_products = $get_all_products->rowCount();
            }else {
				$number_of_products = 0;
			}
         ?>
         <h3><?php echo $number_of_products; ?></h3>
         <p>products added</p>
      </div>

      <div class="box">
         <?php 

			$get_all_users = $conn->prepare("SELECT * FROM users WHERE user_type = ?") or die('query failed');
			$get_all_users->execute(['user']);
			if($get_all_users->rowCount() > 0){
				$number_of_users = $get_all_users->rowCount();
			   }else {
				$number_of_users = 0;
			}
         ?>
         <h3><?php echo $number_of_users; ?></h3>
         <p>regular users</p>
      </div>

      <div class="box">
         <?php 
         $get_all_admins = $conn->prepare("SELECT * FROM users WHERE user_type = ?") or die('query failed');
			$get_all_admins->execute(['admin']);
			if($get_all_admins->rowCount() > 0){
			$number_of_admins = $get_all_admins->rowCount();
			   }else {
				$number_of_admins = 0;
			}
         ?>
         <h3><?php echo $number_of_admins; ?></h3>
         <p>admin users</p>
      </div>

      <div class="box">
         <?php 
         $get_all_users_num = $conn->prepare("SELECT * FROM users") or die('query failed');
			$get_all_users_num->execute();
			if($get_all_users_num->rowCount() > 0){
			$number_of_all_users = $get_all_users_num->rowCount();
			   }else {
				$number_of_all_users = 0;
			}
         ?>
         <h3><?php echo $number_of_all_users; ?></h3>
         <p>total accounts</p>
      </div>

      <div class="box">
         <?php 
         $get_all_messages = $conn->prepare("SELECT * FROM message") or die('query failed');
			$get_all_messages->execute();
			if($get_all_messages->rowCount() > 0){
				$number_of_messages = $get_all_messages->rowCount();
			   }else {
				$number_of_messages = 0;
			}
         ?>
         <h3><?php echo $number_of_messages; ?></h3>
         <p>new messages</p>
      </div>

   </div>

</section>
<!-- admin dashboard section ends -->
<!-- custom admin js file link  -->
<script src="js/admin_script.js"></script>

</body>
</html>
