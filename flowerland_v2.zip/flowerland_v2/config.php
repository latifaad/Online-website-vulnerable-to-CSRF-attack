<?php


// This file contains useful functions
include __dir__ . '/helper.php';

// Connect to DB
try {
    $conn = new PDO("mysql:host=localhostxxx;dbname=flowerland_db","latifa","1234"
	,array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
} catch (Exception $error) {
    die("ERROR: Couldn't connect. {$error->getMessage()}");
}

?> 
