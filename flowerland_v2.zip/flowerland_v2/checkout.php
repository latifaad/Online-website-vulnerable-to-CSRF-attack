<?php
include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];
if(!isset($user_id)){
   header('location: login.php');
}




$grand_total = 0;
$stmt = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ? ") or die('query failed');
$stmt->execute([$_SESSION['user_id']]);
if($stmt->rowCount() > 0){
   $rows = $stmt->fetchAll() ?? null;
   foreach($rows as $fetch_cart){
      $total_price = ($fetch_cart['price'] * $fetch_cart['quantity']);
      $grand_total += $total_price;


if(isset($_POST['order_btn'])){

   //Security, remove comments to enable it
   $token = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_STRING);
   if (!$token || $token !== $_SESSION['token']) {
     die("Hacking attempt, go away hacker!");
     
   }

   $name =  $_POST['name'] ?? null;
   $number = $_POST['number'] ?? null;
   $email = $_POST['email'] ?? null;
   $method = $_POST['method'] ?? null;
   $address = 'Address: '. $_POST['city'].', - '. $_POST['pin_code'];
   $placed_on = date('d-M-Y');
   $cart_total = 0;
   $cart_products[] = '';
   $stmt =$conn->prepare("SELECT * FROM `cart` WHERE user_id = ? ") or die('query failed');
   $stmt->execute([$_SESSION['user_id']]);
   if( $stmt->rowCount() > 0){
         $rows = $stmt->fetchAll() ?? null;
         foreach($rows as $cart_item){
         $cart_products[] = $cart_item['name'].' ('.$cart_item['quantity'].') ';
         $sub_total = ($cart_item['price'] * $cart_item['quantity']);
         $cart_total += $sub_total;
      }
   }

   $total_products = implode(', ',$cart_products);
   //$stmt = $conn->prepare("SELECT * FROM `orders` WHERE name = ? AND number = ? AND email = ? AND method = ? AND address = ?") or die('query failed');
   if($cart_total == 0){
      $message[] = 'your cart is empty';
   }elseif(!preg_match ('/^([a-zA-Z]{2,32}+)$/', $name)){
      $message[] = "Please Enter Valid Name (ONLY alphabets and whitespace are allowed)";
   }elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
      $message[] = "Please Enter Valid Email address";
   }elseif(!preg_match('/^\d{3,6}$/', $_POST['pin_code'])){
      $message[] = "Please Enter Valid Pin Code (3-6 digits)";
   }elseif(preg_match('@[^\w]@',$_POST['city'])){
      $message[] = "Please Enter Valid Input";
   }elseif(!preg_match('/^\d{10}$/', $number)){
      $message[] = "Please Enter Valid Number";
   }else{
         $stmt=$conn->prepare("INSERT INTO `orders` (user_id, name, number, email, method, address, total_products, total_price, placed_on) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)") or die('query failed');
         $result = $stmt->execute([$_SESSION['user_id'],$name, $number, $email, $method, $address, $total_products, $grand_total, $placed_on, $user_id]);
         if($result){
            $message[] = 'order placed successfully!';
            $stmt = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?") or die('query failed');
            $stmt->execute([$_SESSION['user_id']]);
   
   }
   
}

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="shortcut icon" href="images/logo1.jpg" type="image/x-icon">
   <title>checkout</title>
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <!-- custom js file link  -->
   <script src="js/script.js"></script>
</head>
<body> 
<?php include 'header.php'; ?>
<div class="heading">
   <h3>checkout</h3>
   <p> <a href="home.php">home</a> / checkout </p>
</div>
<section class="display-order">
   <p> <?php echo $fetch_cart['name']; ?> <span>(<?php echo $fetch_cart['price'].'SR x '. $fetch_cart['quantity']; ?>)</span> </p>
   <?php
      }
   }else{
      echo '<p class="empty">your cart is empty</p>';
   }
   ?>
   <div class="grand-total"> grand total : <span><?php echo $grand_total; ?>SR</span> </div>
</section>
<section class="checkout">
   <form action="" method="post">
      <h3>place your order</h3>
      <div class="flex">
         <div class="inputBox">
            <span>Name :</span>
            <input type="text" name="name" placeholder="enter your name" maxlength='32'>
         </div>
         <div class="inputBox">
            <span>Email :</span>
            <input type="email" name="email" placeholder="enter your email">
         </div>
         <div class="inputBox">
            <span>Number :</span>
            <input type="number" name="number" placeholder="enter your number">
         </div>
         <div class="inputBox">
            <span>City :</span>
            <input type="text" name="city" placeholder="e.g. Dammam " maxlength='32'>
         </div>
         <div class="inputBox">
            <span>pin-code :</span>
            <input type="number" name="pin_code" placeholder="e.g. 3062">
         </div>
         <div class="inputBox">
            <span>Payment Method :</span>
            <select name="method">
               <option value="cash on delivery">cash on delivery</option>
               <option value="credit card">credit card</option>
               <option value="paypal">paypal</option>
            </select>
         </div>
      </div>
      <input type="hidden" name="token" value="<?php echo $_SESSION['token'] ?? null ?>">
      <input type="submit" value="place order" class="btn" name="order_btn">
   </form>
</section>

<?php include 'footer.php'; ?>

</body>
</html>
